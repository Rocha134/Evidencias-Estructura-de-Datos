#include "registro.h"
#include <fstream>
#include <vector>
#include <sstream>
using namespace std;


ifstream in("bitacora.txt");
vector<string> registros;


int MesInt(string mes){
    if (mes == "Jan"){
        return 1;
    }
    else if (mes == "Feb"){
        return 2;
    }
    else if (mes == "Mar"){
        return 3;
    }
    else if (mes == "Apr"){
        return 4;
    }
    else if (mes == "May"){
        return 5;
    }
    else if (mes == "Jun"){
        return 6;
    }
    else if (mes == "Jul"){
        return 7;
    }
    else if (mes == "Aug"){
        return 8;
    }
    else if (mes == "Sep"){
        return 9;
    }
    else if (mes == "Oct"){
        return 10;
    }
    else if (mes == "Nov"){
        return 11;
    }
    else if (mes == "Dec"){
        return 12;
    }
    else {
        return 0;
    }
}

//Complejidad O(n)
void Switch (Registro* a1) {
    Registro* x = a1;
    Registro* y = a1->GetAfter();
    Registro* t = NULL;

    t = x->GetBefore();
    x->SetBefore(y);
    y->SetBefore(t);

    t = x->GetAfter();
    x->SetAfter(y->GetAfter());
    y->SetAfter(x);
}

//Complejidad O(n2)
void Sort(Registro** head, Registro** tail){
    Registro* actual = *head;
    for (int i = 0; i < registros.size(); i++)
    {
        for (int j = i; j < registros.size(); j++)
        {
            if (actual->GetIP1() < actual->GetAfter()->GetIP1())
            {
                Switch(actual);
            }
            else if (actual->GetIP1() == actual->GetAfter()->GetIP1())
            {
                if (actual->GetIP2() < actual->GetAfter()->GetIP2())
                {
                    Switch(actual);
                }
                else if (actual->GetIP2() == actual->GetAfter()->GetIP2())
                {
                    if (actual->GetIP3() < actual->GetAfter()->GetIP3())
                    {
                        Switch(actual);
                    }
                    else if (actual->GetIP3() == actual->GetAfter()->GetIP3())
                    {
                        if (actual->GetIP4() < actual->GetAfter()->GetIP4())
                        {
                            Switch(actual);
                        }
                        else if (actual->GetIP4() == actual->GetAfter()->GetIP4())
                        {
                            if (actual->GetIP5() < actual->GetAfter()->GetIP5())
                            {
                                Switch(actual);
                            }
                            else if (actual->GetIP5() == actual->GetAfter()->GetIP5())
                            {
                                if (actual->GetMes() < actual->GetAfter()->GetMes())
                                {
                                    Switch(actual);
                                }
                                else if (actual->GetMes() == actual->GetAfter()->GetMes())
                                {
                                    if (actual->GetDia() < actual->GetAfter()->GetDia())
                                    {
                                        Switch(actual);
                                    }
                                    else if (actual->GetDia() == actual->GetAfter()->GetDia())
                                    {
                                        if (actual->GetHora() < actual->GetAfter()->GetHora())
                                        {
                                            Switch(actual);
                                        }
                                        else if (actual->GetHora() == actual->GetAfter()->GetHora())
                                        {
                                            if (actual->GetMinuto() < actual->GetAfter()->GetMinuto())
                                            {
                                                Switch(actual);
                                            }
                                            else if (actual->GetMinuto() == actual->GetAfter()->GetMinuto())
                                            {
                                                if (actual->GetSegundo() < actual->GetAfter()->GetSegundo())
                                                {
                                                    Switch(actual);
                                                }
                                                else if (actual->GetSegundo() == actual->GetAfter()->GetSegundo()){
                                                    if (actual->GetMensaje() > actual->GetAfter()->GetMensaje())
                                                    {
                                                        Switch(actual);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }

    }


    actual = actual->GetAfter();

}

Registro* FindStart(Registro** head, Registro** tail, string ip){
    Registro* actual = *head;
    stringstream temp(ip);
    string palabra;

    getline(temp, palabra, ' ');
    int mes = MesInt(palabra);

    getline(temp, palabra, ' ');
    int dia = stoi(palabra);

    getline(temp, palabra, ':');
    int hora = stoi(palabra);

    getline(temp, palabra, ':');
    int minuto = stoi(palabra);

    getline(temp, palabra, ' ');
    int segundo = stoi(palabra);

    getline(temp, palabra, '.');
    int ip1 = stoi(palabra);

    getline(temp, palabra, '.');
    int ip2 = stoi(palabra);

    getline(temp, palabra, '.');
    int ip3 = stoi(palabra);

    getline(temp, palabra, ':');
    int ip4 = stoi(palabra);

    getline(temp, palabra, ' ');
    int ip5 = stoi(palabra);

    getline(temp, palabra);
    string mensaje = palabra;

    while (actual != NULL)
    {
        if (actual->GetIP1() >  ip1)
        {
            return actual;
        }
        else if (actual->GetIP1() == ip1)
        {
            if (actual->GetIP2() > ip2)
            {
                return actual;
            }
            else if (actual->GetIP2() == ip2)
            {
                if (actual->GetIP3() > ip3)
                {
                    return actual;
                }
                else if (actual->GetIP3() == ip3)
                {
                    if (actual->GetIP4() > ip4)
                    {
                        return actual;
                    }
                    else if (actual->GetIP4() == ip4)
                    {
                        if (actual->GetIP5() > ip5)
                        {
                            return actual;
                        }
                        else if (actual->GetIP5() == ip5)
                        {
                            if (actual->GetMes() > mes)
                            {
                                return actual;
                            }
                            else if (actual->GetMes() == mes)
                            {
                                if (actual->GetDia() > dia)
                                {
                                    return actual;
                                }
                                else if (actual->GetDia() == dia)
                                {
                                    if (actual->GetHora() > hora)
                                    {
                                        return actual;
                                    }
                                    else if (actual->GetHora() == hora)
                                    {
                                        if (actual->GetMinuto() > minuto)
                                        {
                                            return actual;
                                        }
                                        else if (actual->GetMinuto() == minuto)
                                        {
                                            if (actual->GetSegundo() > segundo)
                                            {
                                                return actual;
                                            }
                                            else if (actual->GetSegundo() == segundo){
                                                if (actual->GetMensaje() > mensaje)
                                                {
                                                    return actual;
                                                }
                                                else if (actual->GetMensaje() == mensaje){
                                                    return actual;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        actual = actual->GetAfter();
    }
    return NULL;
}

Registro* FindEnd(Registro** head, Registro** tail, string ip){
    Registro* actual = *tail;
    stringstream temp(ip);
    string palabra;

    getline(temp, palabra, ' ');
    int mes = MesInt(palabra);

    getline(temp, palabra, ' ');
    int dia = stoi(palabra);

    getline(temp, palabra, ':');
    int hora = stoi(palabra);

    getline(temp, palabra, ':');
    int minuto = stoi(palabra);

    getline(temp, palabra, ' ');
    int segundo = stoi(palabra);

    getline(temp, palabra, '.');
    int ip1 = stoi(palabra);

    getline(temp, palabra, '.');
    int ip2 = stoi(palabra);

    getline(temp, palabra, '.');
    int ip3 = stoi(palabra);

    getline(temp, palabra, ':');
    int ip4 = stoi(palabra);

    getline(temp, palabra, ' ');
    int ip5 = stoi(palabra);

    getline(temp, palabra);
    string mensaje = palabra;
//Complejidad O(n)
    while (actual != NULL)
    {
        if (actual->GetIP1() <  ip1)
        {
            return actual;
        }
        else if (actual->GetIP1() == ip1)
        {
            if (actual->GetIP2() < ip2)
            {
                return actual;
            }
            else if (actual->GetIP2() == ip2)
            {
                if (actual->GetIP3() < ip3)
                {
                    return actual;
                }
                else if (actual->GetIP3() == ip3)
                {
                    if (actual->GetIP4() < ip4)
                    {
                        return actual;
                    }
                    else if (actual->GetIP4() == ip4)
                    {
                        if (actual->GetIP5() < ip5)
                        {
                            return actual;
                        }
                        else if (actual->GetIP5() == ip5)
                        {
                            if (actual->GetMes() < mes)
                            {
                                return actual;
                            }
                            else if (actual->GetMes() == mes)
                            {
                                if (actual->GetDia() < dia)
                                {
                                    return actual;
                                }
                                else if (actual->GetDia() == dia)
                                {
                                    if (actual->GetHora() < hora)
                                    {
                                        return actual;
                                    }
                                    else if (actual->GetHora() == hora)
                                    {
                                        if (actual->GetMinuto() < minuto)
                                        {
                                            return actual;
                                        }
                                        else if (actual->GetMinuto() == minuto)
                                        {
                                            if (actual->GetSegundo() < segundo)
                                            {
                                                return actual;
                                            }
                                            else if (actual->GetSegundo() == segundo){
                                                if (actual->GetMensaje() < mensaje)
                                                {
                                                    return actual;
                                                }
                                                else if (actual->GetMensaje() == mensaje){
                                                    return actual;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        actual = actual->GetBefore();
    }
    return NULL;
}

int main(){
    cout << "0";
    string linea;

    Registro* head = NULL;
    Registro* tail = NULL;
    Registro** h = &head;
    Registro** t = &tail;


    int counter = 0;
    while(getline(in,linea)){
        registros.push_back(linea);
        counter++;
    }
    string palabra;
    Registro* r;
    for (int i = 0; i < registros.size(); i++){
        if (head == NULL){
            r = new Registro;
            *r = Registro(head, tail);
            head = r;
            tail = r;
        }
        else{
            r = new Registro;
            *r = Registro(NULL, head);
            head->SetBefore(r);
            head = r;
        }

        stringstream temp(registros[i]);

        getline(temp, palabra, ' ');
        r->SetMes(MesInt(palabra));

        getline(temp, palabra, ' ');
        r->SetDia((stoi(palabra)));

        getline(temp, palabra, ':');
        r->SetHora((stoi(palabra)));

        getline(temp, palabra, ':');
        r->SetMinuto(stoi(palabra));

        getline(temp, palabra, ' ');
        r->SetSegundo(stoi(palabra));

        getline(temp, palabra, '.');
        r->SetIP1(stoi(palabra));

        getline(temp, palabra, '.');
        r->SetIP2(stoi(palabra));

        getline(temp, palabra, '.');
        r->SetIP3(stoi(palabra));

        getline(temp, palabra, ':');
        r->SetIP4(stoi(palabra));

        getline(temp, palabra, ' ');
        r->SetIP5(stoi(palabra));

        getline(temp, palabra);
        r->SetMensaje(palabra);


    }

    Sort(h, t);
    fstream sorted;
	sorted.open("sorted.txt", ios::out);
    Registro* z = tail;

    //Complejidad O(n)
    while (z != NULL){
        sorted << z->Print() << endl;
        z = z->GetBefore();
    }

    string ipi;
    string ipf;
    cin >> ipi;
    cin >> ipf;

    Registro* inicio = FindStart(h, t, ipi);
    Registro* fin = FindEnd(h, t, ipf);

    //Cambiar todo esto
    //Complejidad O(n)
    Registro* act = inicio;
    while (act != NULL){
        cout << inicio->Print() << endl;
        act = act->GetAfter();
    }


    return 1;
}
