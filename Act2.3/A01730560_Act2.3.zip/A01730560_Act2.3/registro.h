#include <iostream>

using namespace std;

class Registro{
    private:
        int dia;
        int mes;
        int hora;
        int minuto;
        int segundo;
        int ip1;
        int ip2;
        int ip3;
        int ip4;
        int ip5;
        string mensaje;

        Registro* before;
        Registro* after;

        string IntMonth();

    public:
        Registro();
        Registro(Registro* b, Registro* a);

        int GetDia(){return dia;};
        int GetMes(){return mes;};
        int GetHora(){return hora;};
        int GetMinuto(){return minuto;};
        int GetSegundo(){return segundo;};
        int GetIP1(){return ip1;};
        int GetIP2(){return ip2;};
        int GetIP3(){return ip3;};
        int GetIP4(){return ip4;};
        int GetIP5(){return ip5;};
        string GetMensaje(){return mensaje;};
        Registro* GetBefore(){return before;};
        Registro* GetAfter(){return after;};


        void SetDia(int x){dia = x;};
        void SetMes(int x){mes = x;};
        void SetHora(int x){hora = x;};
        void SetMinuto(int x){minuto = x;};
        void SetSegundo(int x){segundo = x;};
        void SetIP1(int x){ip1 = x;};
        void SetIP2(int x){ip2 = x;};
        void SetIP3(int x){ip3 = x;};
        void SetIP4(int x){ip4 = x;};
        void SetIP5(int x){ip5 = x;};
        void SetMensaje(string x){mensaje = x;};
        void SetBefore(Registro* x){before = x;};
        void SetAfter(Registro* x){after = x;};

        string Print();
};

Registro::Registro(){
    dia = 0;
    mes = 0;
    hora = 0;
    minuto = 0;
    segundo = 0;
    ip1 = 0;
    ip2 = 0;
    ip3 = 0;
    ip4 = 0;
    ip5 = 0;
    mensaje = "";

    before = NULL;
    after = NULL;
}

Registro::Registro(Registro* b, Registro* a){
    dia = 0;
    mes = 0;
    hora = 0;
    minuto = 0;
    segundo = 0;
    ip1 = 0;
    ip2 = 0;
    ip3 = 0;
    ip4 = 0;
    ip5 = 0;
    mensaje = "";

    before = b;
    after = a;
}

string Registro::IntMonth(){
    if (mes == 1){
        return "Jan";
    }
    else if (mes == 2){
        return "Feb";
    }
    else if (mes == 3){
        return "Mar";
    }
    else if (mes == 4){
        return "Apr";
    }
    else if (mes == 5){
        return "May";
    }
    else if (mes == 6){
        return "Jun";
    }
    else if (mes == 7){
        return "Jul";
    }
    else if (mes == 8){
        return "Aug";
    }
    else if (mes == 9){
        return "Sep";
    }
    else if (mes == 10){
        return "Oct";
    }
    else if (mes == 1){
        return "Nov";
    }
    else if (mes == 12){
        return "Dec";
    }
    else {
        return "";
    }
}


string Registro::Print(){
    return IntMonth() + " " + to_string(dia) + " " + to_string(hora) + ":" + to_string(minuto) + ":" + to_string(segundo) + " " 
    + to_string(ip1) + "." + to_string(ip2) + "." + to_string(ip3) + "." + to_string(ip4) + ":" + to_string(ip5) + " " + mensaje;
}